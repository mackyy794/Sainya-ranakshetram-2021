python3 -c "print('11')" | ./a.out 
